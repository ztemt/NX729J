/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (c) 2022 Qualcomm Innovation Center, Inc. All rights reserved.
 */

#define CONFIG_TOUCHSCREEN_SYNAPTICS_TCM 1
#define CONFIG_TOUCHSCREEN_SYNAPTICS_TCM_I2C 1
#define CONFIG_TOUCHSCREEN_SYNAPTICS_TCM_CORE 1
#define CONFIG_TOUCHSCREEN_SYNAPTICS_TCM_TOUCH 1

