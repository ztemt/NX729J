/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (c) 2021, Qualcomm Innovation Center, Inc. All rights reserved.
 */

#define CONFIG_TOUCHSCREEN_NT36XXX_I2C 1
#define CONFIG_TOUCHSCREEN_GOODIX_BRL 1
#define CONFIG_TOUCHSCREEN_ATMEL_MXT 1

