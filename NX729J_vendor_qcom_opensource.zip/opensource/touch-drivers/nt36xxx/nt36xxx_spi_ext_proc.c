// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (c) 2021 Qualcomm Innovation Center, Inc. All rights reserved.
 */

#define NVT_NT36XXX_SPI

#include "nt36xxx_ext_proc.c"
